import re
import uuid
import subprocess
import threading
import tkinter as tk
from tkinter import filedialog, messagebox
from pathlib import Path
from datetime import datetime

MAX_WALLETS_PER_FILE = 1000
FILE_PREFIX = "wallets-"
FILE_EXTENSION = ".txt"

BG = "#101416"
PANEL = "#151b1e"
PANEL_2 = "#111719"
TEXT = "#edf3f2"
MUTED = "#829391"
TEAL = "#38d6c5"
TEAL_DIM = "#246d68"
LINE = "#29413f"
INPUT_BG = "#0c1113"
SELECT_BG = "#234a47"
WARN = "#e6c36a"
ERROR = "#ef8585"

FONT = ("Segoe UI", 11)
FONT_SMALL = ("Segoe UI", 9)
FONT_MONO = ("Consolas", 11)
FONT_TIMESTAMP = ("Consolas", 11, "bold")


class WalletDiary:
    def __init__(self, root):
        self.root = root
        self.root.title("Solana Wallet Diary")
        self.root.geometry("1100x760")
        self.root.minsize(820, 560)
        self.root.configure(bg=BG)

        self.storage_folder = None
        self.current_file = None
        self.generating = False
        self.ready = False
        self.search_window = None
        self.search_entry = None
        self.search_matches = []
        self.search_index = -1

        self.build_gui()
        self.root.bind("<Control-f>", self.open_find)
        self.root.bind("<Control-F>", self.open_find)
        self.root.after(250, self.start_environment_check)

    def build_gui(self):
        header = tk.Frame(self.root, bg=BG)
        header.pack(fill="x", padx=18, pady=(15, 8))

        tk.Label(header, text="WALLET DIARY", bg=BG, fg=TEXT,
                 font=("Segoe UI Semibold", 16)).pack(side="left")
        self.status_label = tk.Label(header, text="CHECKING COMPUTER...", bg=BG,
                                     fg=WARN, font=FONT_SMALL)
        self.status_label.pack(side="right")
        self.make_line()

        controls = tk.Frame(self.root, bg=BG)
        controls.pack(fill="x", padx=18, pady=10)
        self.folder_button = self.make_button(controls, "SELECT FOLDER", self.choose_folder)
        self.folder_button.pack(side="left")
        self.previous_button = self.make_button(controls, "◀ PREVIOUS", self.previous_file)
        self.previous_button.pack(side="left", padx=(8, 0))
        self.next_button = self.make_button(controls, "NEXT ▶", self.next_file)
        self.next_button.pack(side="left", padx=(8, 0))
        self.newest_button = self.make_button(controls, "NEWEST", self.open_newest_file)
        self.newest_button.pack(side="left", padx=(8, 0))
        self.find_button = self.make_button(controls, "FIND   Ctrl+F", self.open_find)
        self.find_button.pack(side="right")

        self.file_label = tk.Label(self.root, text="No TXT file open", bg=BG,
                                   fg=TEAL, anchor="w", font=("Segoe UI Semibold", 10))
        self.file_label.pack(fill="x", padx=20, pady=(0, 8))

        reader_border = tk.Frame(self.root, bg=LINE)
        reader_border.pack(fill="both", expand=True, padx=18, pady=(0, 10))
        reader_frame = tk.Frame(reader_border, bg=PANEL)
        reader_frame.pack(fill="both", expand=True, padx=1, pady=1)

        self.reader = tk.Text(reader_frame, bg=PANEL, fg=TEXT, insertbackground=TEAL,
                              selectbackground=SELECT_BG, selectforeground=TEXT,
                              font=FONT_MONO, wrap="word", bd=0, relief="flat",
                              padx=18, pady=15, undo=False)
        scrollbar = tk.Scrollbar(reader_frame, command=self.reader.yview, bg=PANEL_2,
                                 troughcolor=BG, activebackground=TEAL_DIM,
                                 relief="flat", bd=0)
        self.reader.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        self.reader.pack(side="left", fill="both", expand=True)
        self.reader.tag_configure("timestamp", foreground=TEAL, font=FONT_TIMESTAMP)
        self.reader.tag_configure("normal", foreground=TEXT)
        self.reader.tag_configure("separator", foreground=MUTED)
        self.reader.tag_configure("search", background="#375653", foreground="#ffffff")
        self.reader.tag_configure("search_current", background="#2f8e85", foreground="#ffffff")
        self.reader.configure(state="disabled")

        self.make_line()
        bottom = tk.Frame(self.root, bg=BG)
        bottom.pack(fill="x", padx=18, pady=(10, 16))
        tk.Label(bottom, text="MESSAGE", bg=BG, fg=MUTED,
                 font=("Segoe UI Semibold", 9)).pack(anchor="w", pady=(0, 5))
        input_border = tk.Frame(bottom, bg=TEAL_DIM)
        input_border.pack(fill="x")
        self.message_entry = tk.Entry(input_border, bg=INPUT_BG, fg=TEXT,
                                      insertbackground=TEAL, selectbackground=SELECT_BG,
                                      selectforeground=TEXT, font=("Segoe UI", 12),
                                      relief="flat", bd=0, state="disabled")
        self.message_entry.pack(fill="x", padx=1, pady=1, ipady=10)
        self.message_entry.bind("<Return>", self.enter_pressed)
        tk.Label(bottom,
                 text="ENTER = generate wallet     •     Ctrl+F = search current TXT     •     Recovery phrases are stored in plain text",
                 bg=BG, fg=MUTED, font=FONT_SMALL).pack(anchor="w", pady=(6, 0))

    def make_line(self):
        tk.Frame(self.root, height=1, bg=LINE).pack(fill="x", padx=18)

    def make_button(self, parent, text, command):
        button = tk.Button(parent, text=text, command=command, bg=PANEL_2, fg=TEXT,
                           activebackground=TEAL_DIM, activeforeground="#ffffff",
                           relief="flat", bd=0, padx=14, pady=7,
                           font=("Segoe UI Semibold", 9), cursor="hand2")
        button.bind("<Enter>", lambda e: button.configure(bg=TEAL_DIM))
        button.bind("<Leave>", lambda e: button.configure(bg=PANEL_2))
        return button

    def start_environment_check(self):
        threading.Thread(target=self.environment_check_worker, daemon=True).start()

    def environment_check_worker(self):
        try:
            wsl = subprocess.run(["wsl", "bash", "-lc", "printf WSL_OK"],
                                 capture_output=True, text=True, timeout=15)
            if wsl.returncode != 0 or "WSL_OK" not in (wsl.stdout or ""):
                raise RuntimeError("WSL is installed but could not start correctly.")

            solana = subprocess.run(["wsl", "bash", "-lc", "command -v solana-keygen && solana-keygen --version"],
                                    capture_output=True, text=True, timeout=15)
            if solana.returncode != 0:
                self.root.after(0, lambda: self.environment_failed(
                    "Solana CLI was not found inside your default WSL/Linux installation.\n\n"
                    "Open README.txt and follow the section named:\n"
                    "IF THE APP SAYS SOLANA-KEYGEN IS MISSING"))
                return

            version = (solana.stdout or "").strip().splitlines()[-1]
            self.root.after(0, lambda v=version: self.environment_ready(v))
        except FileNotFoundError:
            self.root.after(0, lambda: self.environment_failed(
                "Windows Subsystem for Linux (WSL) was not found.\n\n"
                "Open README.txt and follow the section named:\n"
                "IF THE APP SAYS WSL IS MISSING"))
        except Exception as exc:
            msg = str(exc)
            self.root.after(0, lambda m=msg: self.environment_failed(m))

    def environment_ready(self, version):
        self.ready = True
        self.status_label.configure(text=f"READY • {version}", fg=TEAL)
        self.message_entry.configure(state="normal")
        self.message_entry.focus_set()

    def environment_failed(self, message):
        self.ready = False
        self.status_label.configure(text="SETUP NEEDED", fg=ERROR)
        self.message_entry.configure(state="disabled")
        messagebox.showerror("Setup Needed", message + "\n\nThe app will remain open so you can read the message and README.txt.")

    def choose_folder(self):
        folder = filedialog.askdirectory(title="Choose PRIVATE Wallet Diary Folder")
        if not folder:
            return
        self.storage_folder = Path(folder)
        self.status_label.configure(text="READY • STORAGE SELECTED", fg=TEAL)
        self.open_newest_file()
        if self.ready:
            self.message_entry.focus_set()

    def get_wallet_files(self):
        if not self.storage_folder:
            return []
        files = []
        pattern = re.compile(rf"^{re.escape(FILE_PREFIX)}(\d+){re.escape(FILE_EXTENSION)}$")
        for item in self.storage_folder.iterdir():
            if item.is_file():
                match = pattern.match(item.name)
                if match:
                    files.append((int(match.group(1)), item))
        files.sort(key=lambda x: x[0])
        return files

    def file_path_for_number(self, number):
        return self.storage_folder / f"{FILE_PREFIX}{number:04d}{FILE_EXTENSION}"

    def open_newest_file(self):
        if not self.storage_folder:
            messagebox.showinfo("Choose Folder", "Click SELECT FOLDER first.")
            return
        files = self.get_wallet_files()
        if not files:
            path = self.file_path_for_number(1)
            path.touch(exist_ok=True)
            self.open_file(path)
        else:
            self.open_file(files[-1][1])

    def previous_file(self):
        self.move_file(-1)

    def next_file(self):
        self.move_file(1)

    def move_file(self, delta):
        if not self.current_file:
            return
        paths = [x[1] for x in self.get_wallet_files()]
        try:
            index = paths.index(self.current_file)
        except ValueError:
            return
        new_index = index + delta
        if 0 <= new_index < len(paths):
            self.open_file(paths[new_index])

    def open_file(self, path, scroll_bottom=False):
        self.current_file = Path(path)
        try:
            text = self.current_file.read_text(encoding="utf-8")
        except Exception as exc:
            messagebox.showerror("Read Error", str(exc))
            return
        self.file_label.configure(text=self.current_file.name)
        self.display_text(text)
        if scroll_bottom:
            self.reader.see("end")

    def display_text(self, text):
        self.reader.configure(state="normal")
        self.reader.delete("1.0", "end")
        timestamp_pattern = re.compile(r"^\d{2}-\d{2}-\d{4} \d{2}-\d{2}-\d{2}(?:am|pm):")
        for line in text.splitlines(keepends=True):
            if timestamp_pattern.match(line):
                self.reader.insert("end", line, "timestamp")
            elif line.strip() == "------------":
                self.reader.insert("end", line, "separator")
            else:
                self.reader.insert("end", line, "normal")
        self.reader.configure(state="disabled")

    def count_wallets(self, path):
        if not path.exists():
            return 0
        try:
            text = path.read_text(encoding="utf-8")
        except Exception:
            return 0
        pattern = re.compile(r"(?m)^\d{2}-\d{2}-\d{4} \d{2}-\d{2}-\d{2}(?:am|pm):")
        return len(pattern.findall(text))

    def get_generation_file(self):
        files = self.get_wallet_files()
        if not files:
            return self.file_path_for_number(1)
        number, newest = files[-1]
        if self.count_wallets(newest) >= MAX_WALLETS_PER_FILE:
            return self.file_path_for_number(number + 1)
        return newest

    def enter_pressed(self, event=None):
        if self.generating:
            return "break"
        if not self.ready:
            messagebox.showwarning("Setup Needed", "Wallet generation is disabled until the startup check succeeds. Read README.txt for setup help.")
            return "break"
        message = self.message_entry.get().strip()
        if not message:
            return "break"
        if not self.storage_folder:
            messagebox.showwarning("Select Folder", "Click SELECT FOLDER and choose a private storage folder first.")
            return "break"
        self.message_entry.delete(0, "end")
        self.generating = True
        self.message_entry.configure(state="disabled")
        self.status_label.configure(text="GENERATING WALLET...", fg=WARN)
        threading.Thread(target=self.generate_wallet_worker, args=(message,), daemon=True).start()
        return "break"

    def generate_wallet_worker(self, message):
        temp_name = "/tmp/wallet-diary-" + uuid.uuid4().hex + ".json"
        try:
            command = ("set -e; "
                       f"solana-keygen new --no-bip39-passphrase --force --outfile '{temp_name}'; "
                       f"rm -f '{temp_name}'")
            result = subprocess.run(["wsl", "bash", "-lc", command],
                                    capture_output=True, text=True, timeout=30)
            combined = (result.stdout or "") + "\n" + (result.stderr or "")
            if result.returncode != 0:
                raise RuntimeError(combined.strip() or "solana-keygen failed.")
            phrase = self.extract_seed_phrase(combined)
            if not phrase:
                raise RuntimeError("The wallet was generated, but the app could not identify the 12-word recovery phrase in solana-keygen's output.")
            words = phrase.split()
            if len(words) != 12:
                raise RuntimeError(f"Expected 12 recovery words, received {len(words)}.")
            self.save_wallet_entry(message, words)
            self.root.after(0, self.generation_complete)
        except Exception as exc:
            error_text = str(exc)
            self.root.after(0, lambda m=error_text: self.generation_failed(m))

    def extract_seed_phrase(self, output):
        lines = output.splitlines()
        for i, line in enumerate(lines):
            if "seed phrase" in line.lower() and "recover" in line.lower():
                for candidate in lines[i + 1:i + 5]:
                    candidate = candidate.strip()
                    words = candidate.split()
                    if len(words) == 12 and all(re.fullmatch(r"[a-z]+", w) for w in words):
                        return candidate
        return None

    def save_wallet_entry(self, message, words):
        destination = self.get_generation_file()
        destination.parent.mkdir(parents=True, exist_ok=True)
        timestamp = datetime.now().strftime("%m-%d-%Y %I-%M-%S%p").lower()
        lines = [
            "   ".join(f"{i+1}. {words[i]}" for i in range(0, 4)),
            "   ".join(f"{i+1}. {words[i]}" for i in range(4, 8)),
            "   ".join(f"{i+1}. {words[i]}" for i in range(8, 12)),
        ]
        entry = f"{timestamp}:\n{message}\n\n{lines[0]}\n{lines[1]}\n{lines[2]}\n"
        existing = destination.exists() and destination.stat().st_size > 0
        with destination.open("a", encoding="utf-8", newline="\n") as file:
            if existing:
                file.write("\n------------\n\n")
            file.write(entry)
        self.current_file = destination

    def generation_complete(self):
        self.generating = False
        self.message_entry.configure(state="normal")
        self.status_label.configure(text="READY • WALLET SAVED", fg=TEAL)
        self.open_file(self.current_file, scroll_bottom=True)
        self.message_entry.focus_set()

    def generation_failed(self, error):
        self.generating = False
        self.message_entry.configure(state="normal" if self.ready else "disabled")
        self.status_label.configure(text="GENERATION FAILED", fg=ERROR)
        if self.ready:
            self.message_entry.focus_set()
        messagebox.showerror("Wallet Generation Error", error + "\n\nNo successful diary entry was saved for this attempt.")

    def open_find(self, event=None):
        if self.search_window:
            try:
                self.search_window.lift()
                self.search_entry.focus_set()
                self.search_entry.select_range(0, "end")
                return "break"
            except tk.TclError:
                self.search_window = None
        window = tk.Toplevel(self.root)
        self.search_window = window
        window.title("Find in Current TXT")
        window.geometry("480x115")
        window.resizable(False, False)
        window.configure(bg=BG)
        window.transient(self.root)
        frame = tk.Frame(window, bg=BG)
        frame.pack(fill="both", expand=True, padx=14, pady=12)
        border = tk.Frame(frame, bg=TEAL_DIM)
        border.pack(side="top", fill="x")
        self.search_entry = tk.Entry(border, bg=INPUT_BG, fg=TEXT, insertbackground=TEAL,
                                     selectbackground=SELECT_BG, selectforeground=TEXT,
                                     font=FONT, relief="flat", bd=0)
        self.search_entry.pack(fill="x", padx=1, pady=1, ipady=7)
        bottom = tk.Frame(frame, bg=BG)
        bottom.pack(fill="x", pady=(9, 0))
        self.find_status = tk.Label(bottom, text="", bg=BG, fg=MUTED, font=FONT_SMALL)
        self.find_status.pack(side="left")
        self.make_button(bottom, "PREVIOUS", self.previous_match).pack(side="right")
        self.make_button(bottom, "NEXT", self.next_match).pack(side="right", padx=(0, 7))
        self.search_entry.bind("<KeyRelease>", self.search_changed)
        self.search_entry.bind("<Return>", self.next_match)
        self.search_entry.bind("<Shift-Return>", self.previous_match)
        window.protocol("WM_DELETE_WINDOW", self.close_find)
        self.search_entry.focus_set()
        return "break"

    def close_find(self):
        if self.search_window:
            self.search_window.destroy()
        self.search_window = None
        self.search_entry = None
        self.search_matches = []
        self.search_index = -1
        self.clear_search_tags()

    def clear_search_tags(self):
        self.reader.configure(state="normal")
        self.reader.tag_remove("search", "1.0", "end")
        self.reader.tag_remove("search_current", "1.0", "end")
        self.reader.configure(state="disabled")

    def search_changed(self, event=None):
        self.perform_search()

    def perform_search(self):
        if not self.search_entry:
            return
        query = self.search_entry.get()
        self.search_matches = []
        self.search_index = -1
        self.clear_search_tags()
        if not query:
            self.find_status.configure(text="")
            return
        self.reader.configure(state="normal")
        start = "1.0"
        while True:
            position = self.reader.search(query, start, stopindex="end", nocase=True)
            if not position:
                break
            end = f"{position}+{len(query)}c"
            self.reader.tag_add("search", position, end)
            self.search_matches.append((position, end))
            start = end
        self.reader.configure(state="disabled")
        if self.search_matches:
            self.search_index = 0
            self.show_current_match()
        else:
            self.find_status.configure(text="No matches")

    def show_current_match(self):
        if not self.search_matches:
            return
        self.reader.configure(state="normal")
        self.reader.tag_remove("search_current", "1.0", "end")
        start, end = self.search_matches[self.search_index]
        self.reader.tag_add("search_current", start, end)
        self.reader.tag_raise("search_current")
        self.reader.configure(state="disabled")
        self.reader.see(start)
        self.find_status.configure(text=f"{self.search_index + 1} / {len(self.search_matches)}")

    def next_match(self, event=None):
        if not self.search_matches:
            self.perform_search()
        if not self.search_matches:
            return "break"
        self.search_index = (self.search_index + 1) % len(self.search_matches)
        self.show_current_match()
        return "break"

    def previous_match(self, event=None):
        if not self.search_matches:
            self.perform_search()
        if not self.search_matches:
            return "break"
        self.search_index = (self.search_index - 1) % len(self.search_matches)
        self.show_current_match()
        return "break"


if __name__ == "__main__":
    root = tk.Tk()
    WalletDiary(root)
    root.mainloop()
