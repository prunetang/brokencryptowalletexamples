@echo off
setlocal
cd /d "%~dp0"
title Solana Wallet Diary Launcher

where py >nul 2>nul
if %errorlevel%==0 (
    py -3 wallet_diary.py
    goto :end
)

where python >nul 2>nul
if %errorlevel%==0 (
    python wallet_diary.py
    goto :end
)

cls
echo ============================================================
echo  SOLANA WALLET DIARY - PYTHON IS NOT INSTALLED OR NOT FOUND
echo ============================================================
echo.
echo This app needs Python 3 for Windows.
echo.
echo Install Python 3, then run this launcher again.
echo During Python installation, enable the option that adds Python to PATH.
echo.
echo See README.txt for the complete beginner guide.
echo.
pause

:end
endlocal
