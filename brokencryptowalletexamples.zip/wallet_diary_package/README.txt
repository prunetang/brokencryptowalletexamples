SOLANA WALLET DIARY — BEGINNER GUIDE
====================================

WHAT THIS APP DOES
------------------
Solana Wallet Diary is a Windows desktop app that:
• Lets you choose where your wallet diary files are stored.
• Lets you type a message and press Enter.
• Generates a brand-new random Solana wallet using Solana's solana-keygen tool inside WSL/Linux.
• Saves the timestamp, your message, and the wallet's 12-word recovery phrase.
• Shows the entire current diary TXT file in a dark, searchable reader.
• Starts a new TXT file automatically after 1,000 wallets.

IMPORTANT SECURITY WARNING
--------------------------
The TXT files contain REAL WALLET RECOVERY PHRASES in plain text.
Anyone who obtains one of those phrases can control that wallet and any cryptocurrency stored in it.

Do not email the diary files, upload them to public/cloud locations, or share screenshots containing recovery phrases.
Back up important wallet information appropriately before placing funds in a wallet.

WHAT YOU NEED
-------------
1. Windows 10 or Windows 11.
2. Python 3 for Windows, including Tkinter.
3. Windows Subsystem for Linux (WSL).
4. A Linux distribution in WSL, normally Ubuntu.
5. Solana CLI installed inside that Linux distribution.

The app checks WSL and Solana automatically when it starts.

FIRST START
-----------
1. Unzip this entire ZIP into a normal folder.
2. Double-click START_WALLET_DIARY.bat.
3. If Windows asks what program should open .py files, cancel that prompt and install Python first.
4. Read the startup status shown by the app.
5. Click SELECT FOLDER and choose a private folder where you want the diary TXT files stored.
6. Type a message in the MESSAGE box at the bottom.
7. Press Enter.
8. Wait briefly while the wallet is generated.
9. The new entry appears at the bottom of the reader.

THE SAVED FORMAT
----------------
Example:

10-03-2026 06-51-27am:
Example message.

1. word   2. word   3. word   4. word
5. word   6. word   7. word   8. word
9. word   10. word  11. word  12. word

------------

The real entries contain actual recovery words.

HISTORY
-------
The app stores up to 1,000 wallet entries per TXT file:

wallets-0001.txt
wallets-0002.txt
wallets-0003.txt
...

Use PREVIOUS, NEXT, and NEWEST to move through the diary files.
The entire selected TXT file is displayed, not just one wallet.

SEARCH
------
Press Ctrl+F or click FIND.
Type anything that appears in the current TXT file.
Use Enter/NEXT for the next match.
Use Shift+Enter/PREVIOUS for the previous match.

IMPORTANT: Ctrl+F searches only the currently open TXT file.

WHAT HAPPENS TO THE SOLANA JSON FILE?
-------------------------------------
The app creates a temporary Solana keypair file only long enough for solana-keygen to generate the wallet. The temporary JSON is then deleted.

The recovery phrase written to your selected TXT diary is therefore extremely important. Do not assume there is another permanent JSON copy elsewhere.

The app does NOT replace or modify your normal ~/.config/solana/id.json wallet.

IF THE APP SAYS WSL IS MISSING
------------------------------
Open Windows Terminal or PowerShell as Administrator and install WSL according to Microsoft's current Windows instructions. Ubuntu is a common choice.

After installation, open Ubuntu once and finish its initial username/password setup. Then restart the Wallet Diary app.

IF THE APP SAYS SOLANA-KEYGEN IS MISSING
----------------------------------------
Solana CLI must be installed inside the WSL/Linux distribution that Windows opens with the command "wsl".

Open Ubuntu and test:

solana-keygen --version

If that command is not recognized, install the current Solana CLI using the official Solana/Anza installation instructions, then close and reopen the Wallet Diary app.

TESTING BEFORE USING REAL FUNDS
-------------------------------
Generate a test wallet first. Confirm that an entry appears in the TXT file and that it contains exactly 12 numbered recovery words.

Before relying on the app for valuable funds, independently verify that you can restore a test wallet from its recovery phrase using trusted Solana wallet tooling.

COMMON QUESTIONS
----------------
Q: Does pressing Enter generate a new wallet?
A: Yes, provided there is text in the MESSAGE box and the startup checks passed.

Q: Are the wallets random?
A: The app asks Solana's solana-keygen utility to generate a new keypair each time. It does not intentionally derive the next wallet from the previous wallet.

Q: Does my message affect the wallet?
A: No. The message is diary text only. It is not used as randomness or as part of the recovery phrase.

Q: Can I edit the TXT files myself?
A: Technically yes, but changing their structure can confuse wallet counting. Make backups before manually editing them.

Q: Can I open the TXT files in Notepad?
A: Yes.

Q: Can I share a diary TXT file?
A: You should not. It contains wallet recovery phrases.

Q: What if I lose the diary file?
A: You may lose the recovery information for wallets recorded only in that file. Maintain appropriate secure backups.

Q: Does the app send the phrases over the Internet?
A: This program itself contains no networking code. It invokes the locally installed solana-keygen program through WSL and writes the resulting phrase to a local TXT file.

FILES IN THIS PACKAGE
---------------------
START_WALLET_DIARY.bat    Easy Windows launcher.
wallet_diary.py           Main application.
README.txt                This guide.
QUICK_START.txt           Short version of the instructions.

